import csv
import json

def csv_to_json(csv_filename, json_filename):
    data = []
    with open(csv_filename, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            data.append(row)

    with open(json_filename, 'w', encoding='utf-8') as jsonfile:
        json.dump(data, jsonfile, indent=4)

csv_to_json("programmazione.csv", "programmazione.json")
