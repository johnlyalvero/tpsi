import java.io.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class CSVToJSON {
    public static void main(String[] args) throws IOException {
        String csvFile = "programmazione.csv";
        String jsonFile = "programmazione.json";
        
        BufferedReader br = new BufferedReader(new FileReader(csvFile));
        String line = br.readLine(); // Legge l'header
        String[] headers = line.split(",");
        JSONArray jsonArray = new JSONArray();

        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            JSONObject jsonObj = new JSONObject();
            for (int i = 0; i < headers.length; i++) {
                jsonObj.put(headers[i].trim(), values[i].trim());
            }
            jsonArray.put(jsonObj);
        }
        br.close();

        try (FileWriter file = new FileWriter(jsonFile)) {
            file.write(jsonArray.toString(4));
        }
    }
}