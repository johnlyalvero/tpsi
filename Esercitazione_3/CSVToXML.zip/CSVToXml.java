import java.io.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import org.xml.sax.SAXException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class CSVToXml {
    public static void main(String[] args) throws ParserConfigurationException, TransformerException, IOException {
        String csvFile = "programmazione.csv";
        String xmlFile = "programmazione.xml";
        
        BufferedReader br = new BufferedReader(new FileReader(csvFile));
        String line = br.readLine(); // Legge l'header
        String[] headers = line.split(",");

        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();

        Element rootElement = doc.createElement("programmazione");
        doc.appendChild(rootElement);

        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            Element programma = doc.createElement("programma");
            rootElement.appendChild(programma);

            for (int i = 0; i < headers.length; i++) {
                Element element = doc.createElement(headers[i].trim());
                element.appendChild(doc.createTextNode(values[i].trim()));
                programma.appendChild(element);
            }
        }
        br.close();

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new File(xmlFile));
        transformer.transform(source, result);
    }
}