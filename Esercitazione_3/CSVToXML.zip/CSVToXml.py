import csv
import xml.etree.ElementTree as ET

def csv_to_xml(csv_filename, xml_filename):
    tree = ET.Element("programmazione")
    
    with open(csv_filename, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            programma = ET.SubElement(tree, "programma")
            for key, value in row.items():
                elem = ET.SubElement(programma, key)
                elem.text = value
    
    tree = ET.ElementTree(tree)
    tree.write(xml_filename, encoding="utf-8", xml_declaration=True)

csv_to_xml("programmazione.csv", "programmazione.xml")
